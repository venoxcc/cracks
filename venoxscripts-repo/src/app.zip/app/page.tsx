// src/app/page.tsx - Homepage
import Link from 'next/link';

export default function Home() {
  return (
    <div className="max-w-4xl mx-auto p-8">
      <h1 className="text-4xl font-bold mb-6">Lua Scripts Repository</h1>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Link 
          href="/sources" 
          className="p-6 bg-blue-100 rounded-lg hover:bg-blue-200 transition"
        >
          <h2 className="text-2xl font-semibold mb-2">Sources</h2>
          <p>Browse and access source files for Lua scripts</p>
        </Link>
        <Link 
          href="/cracks" 
          className="p-6 bg-green-100 rounded-lg hover:bg-green-200 transition"
        >
          <h2 className="text-2xl font-semibold mb-2">Cracks</h2>
          <p>Browse and access crack scripts</p>
        </Link>
      </div>
    </div>
  );
}
