// src/app/cracks/raw/[filename]/route.ts - GitHub-like raw content display
import { NextRequest, NextResponse } from 'next/server';
import fs from 'fs';
import path from 'path';

export async function GET(
  request: NextRequest,
  { params }: { params: { filename: string } }
) {
  const { filename } = params;
  const filePath = path.join(process.cwd(), 'content', 'cracks', filename);
  
  try {
    if (!fs.existsSync(filePath)) {
      return new NextResponse('File not found', { status: 404 });
    }
    
    const content = fs.readFileSync(filePath);
    
    // Return content as plain text without download headers
    return new NextResponse(content, {
      headers: {
        'Content-Type': 'text/plain; charset=utf-8',
        // No Content-Disposition header at all
        // GitHub also adds this header to prevent content sniffing
        'X-Content-Type-Options': 'nosniff'
      }
    });
  } catch (error) {
    console.error(`Error serving raw crack file ${filename}:`, error);
    return new NextResponse('Error serving file', { status: 500 });
  }
}