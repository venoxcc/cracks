// src/app/cracks/page.tsx - Cracks Explorer Page
import fs from 'fs';
import path from 'path';
import Link from 'next/link';

export const dynamic = 'force-dynamic'; // Force dynamic rendering to get latest files

export default function CracksPage() {
  // Read the files from the content/cracks directory
  const cracksDirectory = path.join(process.cwd(), 'content', 'cracks');
  let crackFiles: string[] = [];
  
  try {
    if (fs.existsSync(cracksDirectory)) {
      crackFiles = fs.readdirSync(cracksDirectory)
        .filter(file => file.endsWith('.lua'));
    }
  } catch (error) {
    console.error('Error reading cracks directory:', error);
  }

  return (
    <div className="max-w-4xl mx-auto p-8">
      <h1 className="text-3xl font-bold mb-6">Crack Files</h1>
      
      {crackFiles.length > 0 ? (
        <ul className="space-y-2">
          {crackFiles.map((file) => (
            <li key={file} className="p-4 bg-gray-100 rounded-md hover:bg-gray-200">
              <Link href={`/cracks/${file.replace('.lua', '')}`} className="block">
                {file}
              </Link>
            </li>
          ))}
        </ul>
      ) : (
        <p>No crack files found.</p>
      )}
    </div>
  );
}