// src/app/sources/page.tsx - Sources Explorer Page
import fs from 'fs';
import path from 'path';
import Link from 'next/link';

export const dynamic = 'force-dynamic'; // Force dynamic rendering to get latest files

export default function SourcesPage() {
  // Read the files from the content/sources directory
  const sourcesDirectory = path.join(process.cwd(), 'content', 'sources');
  let sourceFiles: string[] = [];
  
  try {
    if (fs.existsSync(sourcesDirectory)) {
      sourceFiles = fs.readdirSync(sourcesDirectory)
        .filter(file => file.endsWith('.lua'));
    }
  } catch (error) {
    console.error('Error reading sources directory:', error);
  }

  return (
    <div className="max-w-4xl mx-auto p-8">
      <h1 className="text-3xl font-bold mb-6">Source Files</h1>
      
      {sourceFiles.length > 0 ? (
        <ul className="space-y-2">
          {sourceFiles.map((file) => (
            <li key={file} className="p-4 bg-gray-100 rounded-md hover:bg-gray-200">
              <Link href={`/sources/${file.replace('.lua', '')}`} className="block">
                {file}
              </Link>
            </li>
          ))}
        </ul>
      ) : (
        <p>No source files found.</p>
      )}
    </div>
  );
}