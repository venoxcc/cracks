// src/app/sources/[slug]/page.tsx - Individual Source File Page
import fs from 'fs';
import path from 'path';
import { notFound } from 'next/navigation';
import Link from 'next/link';
import iconv from 'iconv-lite';

export const dynamic = 'force-dynamic'; // Force dynamic rendering to get latest file

export default async function SourcePage({ params }: { params: { slug: string } }) {
  const { slug } = await params;
  const filePath = path.join(process.cwd(), 'content', 'sources', `${slug}.lua`);
  
  let content = '';
  
  try {
    if (fs.existsSync(filePath)) {
       const buffer = fs.readFileSync(filePath);
       content = iconv.decode(buffer, 'utf-16le');
    } else {
      return notFound();
    }
  } catch (error) {
    console.error(`Error reading file ${slug}.lua:`, error);
    return notFound();
  }

  return (
    <div className="max-w-4xl mx-auto p-8">
      <div className="mb-4">
        <Link href="/sources" className="text-blue-600 hover:underline">
          ← Back to Sources
        </Link>
      </div>
      <h1 className="text-3xl font-bold mb-6">{slug}.lua</h1>
      <div className="bg-gray-900 text-white p-4 rounded-lg overflow-x-auto">
        <pre className="whitespace-pre-wrap">{content}</pre>
      </div>
      <div className="mt-4">
        <Link 
          href={`/sources/raw/${slug}.lua`} 
          className="text-blue-600 hover:underline"
          target="_blank"
        >
          Raw File
        </Link>
      </div>
    </div>
  );
}